/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrabajoPracticoJontahannVallejos;

import java.util.Scanner;

/**
 *
 * @author jonat
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        
        
    }// *---*Main*---*
    
    public static void main() {
        
//        System.out.println("Ingrese el precio del producto");
//        
//        Scanner teclado = new Scanner(System.in);
//        int precioProducto = teclado;
//        System.out.println("Ingrese la cantidad de dinero");
//        int cantidadDinero = teclado.;
//       
        
    }
    
        
            
    
    
    
    
    
}
