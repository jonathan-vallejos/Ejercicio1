/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package TrabajoPracticoJontahannVallejos;

import java.util.Scanner;

/**
 *
 * @author jonat
 */
public class Ejercicio1 {

    public static void main(String[] args) {
       
        
        resolverEjercicio1();
        
    
    } // **---- MAIN ----**
    
   
    
    public static void resolverEjercicio1(){
        int[] notas = crearArregloNotas();
        
        // Titulo antes de mostrar las notas
        System.out.println("Las notas obtenidas:");
        for(int a:notas) System.out.println(a); // Esto muestra las notas
        
        // Muestra el titulo y el promedio
        System.out.println("El Promedio de las notas es: " + promedioNotas(notas)); 
        
        // Vareable que sirve para clacular si hay <= 3.
        boolean menorIgual3 = true; 
        
        
        for (int a:notas){
            if(a <=3){
                menorIgual3 = false;
            }
        }       
        if(promedioNotas(notas)>6){
            System.out.println("APROBADO");
        }else if(promedioNotas(notas)<6 && menorIgual3){
            System.out.println("A RECUPERATORIO");
        }else {
            System.out.println("NO APROBADO");
        }
        
        
        
        
        
        
        
        
        
//        for
//                if(promedioNotas(notas) >6){
//                System.out.println("A RECUPERATORIO");
//            }else{
//                System.out.println("APROBADO");
//            }
        
    }
    
    
    public static int[] crearArregloNotas(){
        
        // Pedimos las cantidade de notas con la clase Scanner
        Scanner teclado = new Scanner(System.in);
        System.out.println("¿Cuántos notas quiere guardar?");
        int longitud = teclado.nextInt();
        int[] notas = new int[longitud];
        
        // Pedimos que ingrese los valores y retornamos el arreglo NOTAS.
        System.out.println("Por favor ingrese los "+longitud+" valores:");
        for (int i=0; i<notas.length; i++) {
            System.out.print("Ingrese la Nota N°"+(i+1)+" - ");
            notas[i] = teclado.nextInt();
        }
        
        return notas;        
    }
    
    
    public static int promedioNotas (int[] notas){
        int suma = 0;
        
        // Itineramos para sumar todas las notas y
        // dividirlas por la cantidad de notas.
        for(int a:notas) suma+=a;
        int promedio = suma / notas.length;
        return promedio;
    }  
    
}
